<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="bouncingplus_tileset" tilewidth="36" tileheight="36" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="bouncy_wall.png" width="36" height="36"/>
 </tile>
 <tile id="1">
  <image source="delete_wall.png" width="36" height="36"/>
 </tile>
 <tile id="2">
  <image source="enemy.png" width="36" height="36"/>
 </tile>
 <tile id="3">
  <image source="sword_enemy.png" width="36" height="36"/>
 </tile>
 <tile id="4">
  <image source="shotgun.png" width="36" height="36"/>
 </tile>
</tileset>
